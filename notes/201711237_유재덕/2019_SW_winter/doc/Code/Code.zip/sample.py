import game
import os
import time
import random

rain=game.rain()

def gotoxy(x,y,str): 
    print ("%c[%d;%df" % (0x1B, y, x),end=str)

def print_words(first_node):    #출력 함수
    tmp=first_node
    while tmp.next_node == None:
        gotoxy(tmp.y,tmp.x,tmp.data)

def change_height(first_node):  #y축 하강 함수
    tmp=first_node
    while tmp.next_node == None:
        tmp.y+=1

def clear():
    os.system('clear')

clear()
root=rain.root

for a in range(10):     #10번 실행
    rain.push_node()    #단어를 push
    print_words(root)   #좌표에 따라 출력
    change_height(root) #높이 변경
    time.sleep(2)       #대기


